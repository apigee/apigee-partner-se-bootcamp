 var hotelsResponse = context.getVariable("response.content"),
    // initialize hotels response
    finalResponse = {
      hotels : {
        queryparams : {
          zipcode : context.getVariable("zipcode"),
          radius : context.getVariable("radius")
        }
      }
    };

// add the hotels response
if (hotelsResponse !== null) {
  var hotelsJSON = JSON.parse(hotelsResponse);
  var md = {count : hotelsJSON.count || 0};

  // set current results cursor
  if (hotelsJSON.params && hotelsJSON.params.cursor) {
    md.currentCursor = hotelsJSON.params.cursor[0];
  }
  // set next results cursor
  if (hotelsJSON.cursor) {
    md.nextCursor = hotelsJSON.cursor;
  }
  finalResponse.hotels.resultsMetadata = md;
  // set the list of hotels
  finalResponse.hotels.entities = hotelsJSON.entities;
}

// update the response that will be returned to the client
context.setVariable("response.content", JSON.stringify(finalResponse));
